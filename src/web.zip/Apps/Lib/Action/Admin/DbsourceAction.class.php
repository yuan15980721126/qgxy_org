<?php
/**
 * 
 * Posid (推荐位管理)
 *
 * @package      	YOURPHP
 * @author          liuxun QQ:147613338 <admin@yourphp.cn>
 * @copyright     	Copyright (c) 2008-2011  (http://www.yourphp.cn)
 * @license         http://www.yourphp.cn/license.txt
 * @version        	YourPHP企业网站管理系统 v2.1 2012-10-08 yourphp.cn $
 */
if(!defined("Yourphp")) exit("Access Denied");
class DbsourceAction extends AdminbaseAction {

	protected $dao;
    function _initialize()
    {	
		parent::_initialize();
    }

	
}
?>