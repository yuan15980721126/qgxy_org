<?php
return array ( 'apply' => '3', 'credit' => '4', 'certification' => '5', 'violation' => '6', 'contact' => '7', 'cultivation' => '8', ); ?>