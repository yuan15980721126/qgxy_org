<?php 
return array(
	'role_prve'=>'用户权限',
	'role_allowpost'=>'允许投稿',
	'role_allowpostverify'=>'投稿不需审核',
	'role_allowupgrade'=>'允许自助升级',
	'role_allowsendmessage'=>'允许发短消息',
	'role_allowattachment'=>'允许上传附件',
	'role_allowsearch'=>'搜索权限',
	'role_update'=>'升级价格',
	'role_price_d'=>'包日',
	'role_price_m'=>'包月',
	'role_price_y'=>'包年',
	'role_maxmessagenum'=>'最大短消息数',
	'role_maxpostnum'=>'日最大投稿数',
);
?>