<?php
return array(
	'DELETE_30_DAY'=>'删除1月前的所有记录',
	'DELETE_90_DAY'=>'删除3月前的所有记录',
	 
);
?>