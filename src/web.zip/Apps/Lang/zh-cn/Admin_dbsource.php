<?php
return array(
	'db_host' => '数据库地址',
	'db_name' => '数据源名称',
	'db_port' => '数据库端口',
	'db_username' => '数据库帐号',
	'db_password' => '数据库密码',
	'db_dbname'=> '数据库名称',
	'db_dbtablepre'=> '数据库表前缀',
);
?>