<?php
return array ( 'apply' => '3', 'xypj' => '4', 'xyrz' => '5', 'xywg' => '6', 'Cultivation' => '8', 'experimental' => '9', 'contact' => '7', ); ?>