<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>

<html>

<head>

	<meta name="description" content="<?php echo ($seo_description); ?>">

	<meta name="keywords" content="<?php echo ($seo_keywords); ?>">

	<meta charset="utf-8">

	<meta name="renderer" content="webkit"><!--360 极速模式-->

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no"/>

	<title><?php echo ($seo_title); ?></title>

	<link rel="shortcut icon" href="/Apps/Tpl/Home/Default/Public/images/favicon.ico" />

	<link href="../Public/css/owl.carousel.2.2.1.css" rel="stylesheet" type="text/css" />

	<link href="../Public/css/reset.css" rel="stylesheet" type="text/css" />

	<link href="../Public/css/style.css" rel="stylesheet" type="text/css" />

	<?php if($module_name==Index) : ?>

	<link href="../Public/css/index.css" rel="stylesheet" type="text/css" />

	<?php endif;?>

	<link href="../Public/css/app.css" rel="stylesheet" type="text/css" />

	<!--[if lt IE 9]>

	<script src="../Public/js/html5.js"></script>

	<script src="../Public/js/respond.min.js"></script>

	<![endif]-->

	<script type="text/javascript" src="../Public/js/jquery-min.js"></script>

	<script src="../Public/js/owl.carousel.2.2.1.js" type="text/javascript" charset="utf-8"></script>

</head>

<body>

<div class="wrapper">

	<header>

	<div class="header01">

		<div class="container">

			<div class="row">

				<div class="left">

					<?php  $_result=M("Link")->field("*")->where(" 1  and lang=1 AND status=1 ")->order("listorder desc,id desc")->limit("3")->select();; if ($_result): $k=0;foreach($_result as $key=>$r):++$k;$mod = ($k % 2 );?><a href="<?php echo ($r["siteurl"]); ?>" target="_blank"><?php echo ($r["name"]); ?></a><?php if($k<3) : ?>  | <?php endif; endforeach; endif;?>

				</div>

				<div class="right">

					<a href="/">网站首页</a>｜

					<a href="<?php echo ($Categorys[$T[contact]][url]); ?>"><?php echo ($Categorys[$T[contact]][catname]); ?></a>｜

					<a href="<?php echo ($Categorys[$T[apply]][url]); ?>">信用报名</a>

				</div>

			</div>

		</div>

	</div>

	<div class="header02" style="background-image: url(../Public/images/banner01.jpg);">

		<div class="container">

			<div class="row">

				<div class="img-responsive">

					<a href="/"><img src="<?php echo ($logo); ?>"/></a>

				</div>

			</div>

		</div>

	</div>

	</header>



<style type="text/css">

		.header02{padding: 15px 0;}

		.pull-left{float: left;}

		.footer01{background: #164d81;}

	</style><?php if($module_name!=Index) : ?><div class="breadcrumb">	<div class="container">		<div class="row">			<!--<div class="right">-->				<!--<span>-->					<!--<a class="show" href="/">首页</a> &gt; <?php  $arrparentid = array_filter(explode(',', $Categorys[$catid]['arrparentid'].','.$catid));$icnt = 0;foreach($arrparentid as $cid):$parsestr[] = '<a '.(count($arrparentid)==(++$icnt)?'class="last"':"").' href="'.$Categorys[$cid]['url'].'">'.$Categorys[$cid]['catname'].'</a>'; endforeach;echo implode("<em>&gt;</em>",$parsestr);?> -->				<!--</span>-->			<!--</div>-->		</div>	</div></div><?php endif;?><style type="text/css">	.main{max-width: 1200px;width:100%;}        @media (min-width: 0px) and (max-width: 767px) {             .qyxy_datebaseBox01 .bd .block input{height:37px;}             .qyxy_datebaseBox01 .bd .block button{height:45px;font-size:12px;}             .qyxy_datebaseBox01{padding-bottom:0px;}             .qyxy_datebaseBox01 .right{margin:0;padding-left:0;}             .qyxy_datebaseBox01 .bd .block .right{width:70px;}             .qyxy_datebaseBox02{overflow: auto;}             .qyxy_datebaseBox02 .box{width:900px;}             .qyxy_datebaseBox01 .hd{margin:20px auto 20px;}             .qyxy_datebaseBox01 .bd label .arrow-bottom-b:before{border-width:3px;top:4px;}             .qyxy_datebaseBox01 .bd label span{padding-left:8px;font-size:12px;}             .qyxy_datebaseBox01 .bd label{padding-right:0px;}        }</style><div class="main_bg">	<div class="main clearfix">		<div class="qyxy_datebaseBox01 center clearfix">			<div class="hd">				<img src="../Public/images/pic01.png"/>			</div>			
			<div class="bd" style="max-width:80%;">				<form method="GET" action="/">					<input type="hidden" id="" name="m" value="Search" /> 					<?php if(APP_LANG) : ?>					<input type="hidden" name="l" value="<?php echo ($l); ?>" /> 					<?php endif;?>					<input type="hidden" name="id" value="<?php echo ($catid); ?>" /> 					<input type="hidden" name="type" value="" /> 					<div class="type clearfix">						<label><input type="radio" name="module" id="" data-keyword="企业名称" <?php if($_GET['module']=='credit'||$_GET['module']=='') : ?>checked="checked"<?php endif;?> value="<?php echo ($Categorys[$T[credit]][module]); ?>" /><span class="arrow-bottom-b">示范单位<?php echo ($module); ?></span></label>						<label><input type="radio" name="module" id="" data-keyword="企业名称" <?php if($_GET['module']=='certification') : ?>checked="checked"<?php endif;?> value="Certification" /><span class="arrow-bottom-b">重点单位</span></label>	                    <label><input type="radio" name="module" id="" data-keyword="企业名称" value="<?php echo ($Categorys[$T[cultivation]][module]); ?>" /><span class="arrow-bottom-b">培育单位</span></label>
<label>
<input type="radio" name="module" id="" data-keyword="企业名称" <?php if($_GET['module']=='experimental') : ?>checked="checked"<?php endif;?> value="experimental" /><span class="arrow-bottom-b">试点单位</span></label>
						<label><input type="radio" name="module" id="" data-keyword="信用编码" value="number" /><span  class="arrow-bottom-b">信用编码</span></label>					</div>					<div class="block clearfix relative">						<span><input type="text" name="keyword" id="" value="" placeholder="请输入企业名称"/></span>						<span class="right"><button type="submit" class="noradius noborder"><img src="../Public/images/search.png"/>查询</button></span>					</div>				</form>			</div>		</div>		<!--<div class="qyxy_datebaseBox01 clearfix">			<div class="left">				<img src="../Public/images/bg3.jpg" />			</div>			<div class="right ">				<form method="GET" action="/">					<input type="hidden" id="" name="m" value="Search" /> 					<?php if(APP_LANG) : ?>					<input type="hidden" name="l" value="<?php echo ($l); ?>" /> 					<?php endif;?>					<input type="hidden" name="id" value="<?php echo ($catid); ?>" /> 					<input type="hidden" name="type" value="" /> 					<div class="block clearfix">						<strong>企业信用查询：</strong>						<label><input type="radio" name="module" id="" data-keyword="企业名称" checked="checked" value="<?php echo ($Categorys[$T[credit]][module]); ?>" />示范单位</label>						<label><input type="radio" name="module" id="" data-keyword="企业名称" value="<?php echo ($Categorys[$T[certification]][module]); ?>" />重点单位</label>	                                        <label><input type="radio" name="module" id="" data-keyword="企业名称" value="<?php echo ($Categorys[$T[cultivation]][module]); ?>" />培育单位</label>						<label><input type="radio" name="module" id="" data-keyword="信用编码" value="number" />信用编码</label>						<label><input type="radio" name="module" id="" data-keyword="证书编码" value="code" />证书编码</label>					</div>					<div class="block clearfix">						<span><strong class="searchkeyword">企业名称：</strong></span>						<span><input type="text" name="keyword" id="" value="" /></span>						<span><strong>验证码：</strong></span>						<span>							<input type="text" name="verifyCode" id="code" value="" />							<img style="height: 23px;" src="?g=Home&m=Index&a=verify" onclick="javascript:resetVerifyCode();" class="checkcode"  title="Reset verifycode" id="verifyImage">						</span>						<span><input type="submit" id="" name="" value="查询"/></span>					</div>				</form>			</div>		</div>-->			<div class="qyxy_datebaseBox02 clearfix">			<div class="box">				<div class="hd" style="background-image: url(../Public/images/bg4.jpg);">					<div class="clearfix">						<a href="<?php echo ($Categorys[$T[apply]][url]); ?>" class="btn right">我要提交</a>						<h2>全国信用示范单位</h2>					</div>				</div>				<div class="bd center">					<table border="0" cellspacing="0" cellpadding="0" style="margin-top:-39px">						<tr>							<th style="text-align: left;">企业名称</th>							<th>信用编码</th>							<th>信用分数</th>							<th>颁发日期</th>							<th>有效期至</th>							<th width="95">证书详情</th>						</tr>						<?php  $_result=M("Credit")->field("*")->where(" 1  and lang=1 AND status=1   AND posid =1")->order("id desc")->limit("9")->select();; if ($_result): $i=0;foreach($_result as $key=>$r):++$i;$mod = ($i % 2 );?><tr>								<td style="text-align: left;">									<a href="<?php echo ($r["url"]); ?>" target="_blank"><?php echo ($r["title"]); ?></a>								</td>								<td><?php echo ($r["number"]); ?></td>								<td><?php echo ($r['grade'] > 0) ? $r['grade'] : '-';?></td>								<td><?php echo (todate($r["realtime"],'Y-m-d')); ?></td>								<td><?php echo (todate($r["effecttime"],'Y-m-d')); ?></td>								<td><a href="<?php echo ($r["url"]); ?>" target="_blank">查看</a></td>							</tr><?php endforeach; endif;?>						<tr>							<td colspan="5"></td>							<td>								<a href="javascript:;" class="right">更多>></a>							</td>						</tr>					</table>				</div>			</div>			<div class="box">				<div class="hd" style="background-image: url(../Public/images/bg5.jpg);">					<div class="clearfix">						<a href="<?php echo ($Categorys[$T[apply]][url]); ?>" class="btn right">我要提交</a>						<h2>全国信用重点单位</h2>					</div>				</div>				<div class="bd center">					<table border="0" cellspacing="0" cellpadding="0" style="margin-top:-39px">						<tr>							<th style="text-align: left;">企业名称</th>							<th>信用编码</th>							<th>信用分数</th>							<th>颁发日期</th>							<th>有效期至</th>							<th width="95">证书详情</th>						</tr>						<?php  $_result=M("Certification")->field("*")->where(" 1  and lang=1 AND status=1   AND posid =1")->order("id desc")->limit("9")->select();; if ($_result): $i=0;foreach($_result as $key=>$r):++$i;$mod = ($i % 2 );?><tr>								<td style="text-align: left;">									<a href="<?php echo ($r["url"]); ?>" target="_blank"><?php echo ($r["title"]); ?></a>								</td>								<td><?php echo ($r["number"]); ?></td>								<td><?php echo ($r['grade'] > 0) ? $r['grade'] : '-';?></td>								<td><?php echo (todate($r["realtime"],'Y-m-d')); ?></td>								<td><?php echo (todate($r["effecttime"],'Y-m-d')); ?></td>								<td><a href="<?php echo ($r["url"]); ?>" target="_blank">查看</a></td>							</tr><?php endforeach; endif;?>						<tr>							<td colspan="5"></td>							<td>								<a href="javascript:;" class="right">更多>></a>							</td>						</tr>					</table>				</div>			</div>		</div>			<div class="qyxy_datebaseBox03 clearfix">			<div class="hd">				<h2>重要提示</h2>			</div>			<div class="bd">				1、全国企业信用信息数据库(企业信用查询系统)内信息全部来源于各级主管部门和税务、质检、工商等各级机构信息，<span style="color:#E53333;"><strong>北京中企信办信息管理中心</strong></span>对企业的资质、信用进行的综合评价。数据内所载的各种信息仅供参考，如搜索结果中存在不实信息，请您<strong><span style="color:#E53333;">发起举报</span></strong>（经查实，可对企业信用产生影响）。<br />
2、如有不法单位和个人通过全国企业信用信息数据库内信息资料，从而进行敲诈、勒索等犯罪活动将受法律制裁，<strong style="color:#E53333;white-space:normal;">北京中企信办信息管理中心</strong>不承担相关责任；如利用该数据库内资料进行商业化运作导致的一切经济问题，管理中心不承担相关责任；如使用本平台查询企业资料，视为同意本声明。<br />
3、查询相关企业信用信息时，请输入企业名称（按全称匹配），选择相应的企业查询类型（示范单位、重点单位、培育单位、信用编码），便可以查询到全国企业信用信息数据库内所收纳的企业信用数据信息。如企业名称涉及含有括号的情况，请注意全角半角区别。<br />
<p>
	4、全国企业信用信息数据库(企业信用查询系统)由中企信办信用建设工作委员会创建，网址：http://www.qgxy.org
</p>
<p>
	指导文件：国发〔2014〕21号《国务院关于印发社会信用体系建设规划纲要（2014—2020年）的通知》，北京中企信办信息管理中心协办。
</p>
<p>
	5、全国企业信用信息数据库&nbsp; 电话：400-1022-315&nbsp; 邮箱：zqxban@163.com
</p>			</div>		</div>	</div></div><script type="text/javascript">//	function resetVerifyCode()	$(".qyxy_datebaseBox01 input[type=radio]").focus(function(){		$(".searchkeyword").text($(this).attr('data-keyword')+'：');		if($(this).val()=='number'){			$("input[name=type]").val('number')		}	});	</script><a href="http://mqu.cn/" style="position:fixed;display: none;">mqu.cn</a><a href="http://site.nuo.cn/" style="position:fixed;display: none;">site.nuo.cn</a><footer>

	<div class="footer01">

		<div class="container">

			<!--<div class="row">

				<div class="col-sm-12 col-md-6">

					<?php $r = M('Block')->where(" 1  and lang=1 and pos='fb01' ")->find(); if ($r): echo ($r["content"]); endif;?>

				</div>

				<div class="col-sm-12 col-md-6">

					<div class="text-right right">

						<a href="">京ICP备17046088号</a>

						<p><a href="http://mqu.cn" target="_blank" style="color: #b0b0b0;">Design by MQU.CN</a></p>

					</div>

				</div>

			</div>-->

			<div class="row center">
				<?php $r = M('Block')->where(" 1  and lang=1 and pos='fb01' ")->find(); if ($r): echo ($r["content"]); endif;?>

				<p><a href="http://mqu.cn" target="_blank" style="color: #b0b0b0;display:none; ">Design by MQU.CN</a></p>

			</div>

		</div>

	</div>

</footer>

</div>



<script type="text/javascript">

	$("#keyword").css("color", "#666");

	        	$("#keyword").attr('placeholder','请输入信息关键字');

//	        	$(".search_Index ul li").click(function () {

//	        	 	$(this).addClass('cur').siblings('li').removeClass('cur');

//                  $("#keyword").attr('placeholder',$(this).attr('placeholder'));

//	            });	

	        	

	        	if (!placeholderSupport()) { // 判断浏览器是否支持 placeholder

					$('[placeholder]').focus(function() {

						var input = $(this);

						if (input.val() == input.attr('placeholder')) {

							input.val('');

							input.removeClass('placeholder');

						}

					}).blur(function() {

						var input = $(this);

						if (input.val() == '' || input.val() == input.attr('placeholder')) {

							input.addClass('placeholder');

							input.val(input.attr('placeholder'));

						}

					}).blur();

				};

				function placeholderSupport() {

						return 'placeholder' in document.createElement('input');

				}

				

				

				$(".newbox02 .hd li").hover(function(){

					$(this).addClass('cur').siblings().removeClass('cur');

					$(this).closest('.newbox02').find('.bd ul').eq($(this).index()).show().siblings('ul').hide();

				});

				$(".mobile .tab_list > li").click(function(){

					$(this).addClass('cur').siblings().removeClass('cur');

					$(this).closest('.mobile').find('.tab_content > li').eq($(this).index()).show().siblings('li').hide();

				});

				$(".agency .hd h2").click(function(){

					$(this).addClass('cur').siblings().removeClass('cur');

					$(this).closest('.agency').find('.bd ul').eq($(this).index()).show().siblings('ul').hide();

				});

				$("#slide1").owlCarousel({

					items: 1,

					autoplay: true,

					loop: true,

					nav: false,

					dots: false,

					autoplayTimeout: 3000,

					smartSpeed: 800

				});

				if($(document).width()<768){

					$(".agency .bd ul").owlCarousel({

						items: 1,

						autoplay: true,

						loop: true,

						nav: false,

						dots: false,

						autoplayTimeout: 3000,

						smartSpeed: 800

					});

				}

</script>

</body>

</html>