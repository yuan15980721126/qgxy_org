<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>

<html>

<head>

	<meta name="description" content="<?php echo ($seo_description); ?>">

	<meta name="keywords" content="<?php echo ($seo_keywords); ?>">

	<meta charset="utf-8">

	<meta name="renderer" content="webkit"><!--360 极速模式-->

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no"/>

	<title><?php echo ($seo_title); ?></title>

	<link rel="shortcut icon" href="/Apps/Tpl/Home/Default/Public/images/favicon.ico" />

	<link href="../Public/css/owl.carousel.2.2.1.css" rel="stylesheet" type="text/css" />

	<link href="../Public/css/reset.css" rel="stylesheet" type="text/css" />

	<link href="../Public/css/style.css" rel="stylesheet" type="text/css" />

	<?php if($module_name==Index) : ?>

	<link href="../Public/css/index.css" rel="stylesheet" type="text/css" />

	<?php endif;?>

	<link href="../Public/css/app.css" rel="stylesheet" type="text/css" />

	<!--[if lt IE 9]>

	<script src="../Public/js/html5.js"></script>

	<script src="../Public/js/respond.min.js"></script>

	<![endif]-->

	<script type="text/javascript" src="../Public/js/jquery-min.js"></script>

	<script src="../Public/js/owl.carousel.2.2.1.js" type="text/javascript" charset="utf-8"></script>

</head>

<body>

<div class="wrapper">

	<header>

	<div class="header01">

		<div class="container">

			<div class="row">

				<div class="left">

					<?php  $_result=M("Link")->field("*")->where(" 1  and lang=1 AND status=1 ")->order("listorder desc,id desc")->limit("3")->select();; if ($_result): $k=0;foreach($_result as $key=>$r):++$k;$mod = ($k % 2 );?><a href="<?php echo ($r["siteurl"]); ?>" target="_blank"><?php echo ($r["name"]); ?></a><?php if($k<3) : ?>  | <?php endif; endforeach; endif;?>

				</div>

				<div class="right">

					<a href="/">网站首页</a>｜

					<a href="<?php echo ($Categorys[$T[contact]][url]); ?>"><?php echo ($Categorys[$T[contact]][catname]); ?></a>｜

					<a href="<?php echo ($Categorys[$T[apply]][url]); ?>">信用报名</a>

				</div>

			</div>

		</div>

	</div>

	<div class="header02" style="background-image: url(../Public/images/banner01.jpg);">

		<div class="container">

			<div class="row">

				<div class="img-responsive">

					<a href="/"><img src="<?php echo ($logo); ?>"/></a>

				</div>

			</div>

		</div>

	</div>

	</header>



<style type="text/css">

		.header02{padding: 15px 0;}

		.pull-left{float: left;}

		.footer01{background: #164d81;}

	</style><?php if($module_name!=Index) : ?><div class="breadcrumb">	<div class="container">		<div class="row">			<!--<div class="right">-->				<!--<span>-->					<!--<a class="show" href="/">首页</a> &gt; <?php  $arrparentid = array_filter(explode(',', $Categorys[$catid]['arrparentid'].','.$catid));$icnt = 0;foreach($arrparentid as $cid):$parsestr[] = '<a '.(count($arrparentid)==(++$icnt)?'class="last"':"").' href="'.$Categorys[$cid]['url'].'">'.$Categorys[$cid]['catname'].'</a>'; endforeach;echo implode("<em>&gt;</em>",$parsestr);?> -->				<!--</span>-->			<!--</div>-->		</div>	</div></div><?php endif;?><div class="main clearfix">
				<div class="mainContentLeft credit_show">
					<div class="news_show relative">
						<style type="text/css">
							.content div{font-weight: bold; position: absolute;color: #333;}
							.content .code{left: 48%;top: 29.65%;}
							.content .companyname{font-size: 34px; left: 0;right: 0; top: 36.5%;margin: auto;}
							.content .code1{left: 51%;top: 42%;}
							.content .positon{left: 32%;top: 44.7%;}
							.content .organize{left: 64%;top: 71.2%;}
							.content .year1{left: 67%;top: 74.6%;}
							.content .month1{left: 73.5%;top: 74.6%;}
							.content .day1{left: 77.8%;top: 74.6%;}
							.content .year2{left: 64%;top: 78%;}
							.content .month2{left: 70.5%;top: 78%;}
							.content .day2{left: 74.2%;top: 78%;}
							.content .year3{left: 64%;top: 81.35%;}
							.content .month3{left: 70.5%;top: 81.35%;}
							.content .day3{left: 74.2%;top: 81.35%;}
							@media (max-width: 640px) {
								.mainContentRight{display: none;}
								.content div{font-size: 12px;}
								.content .companyname{font-size: 18px}
								.content .organize{white-space: nowrap;top: 70.4%;}
							}
							@media (max-width: 420px) {
								.content div{transform: scale(0.7);font-weight: normal;transform-origin: left top;}
							}
						</style>
						<div class="hd center"></div>
						<div class="bd">
							<div class="content inline-block relative">
								<img src="../Public/images/zhongdian_1.jpg"/>
								<div class="code"><?php echo ($number); ?></div>
								<div class="companyname"><?php echo ($title); ?></div>
								<div class="code1"><?php echo ($xinyongcode); ?></div>
								<div class="positon"><?php echo ($address); ?></div>
								<div class="organize"><?php echo ($organize); ?></div>
								<div class="year1"><?php echo (todate($gettime,'Y')); ?></div>
								<div class="month1"><?php echo (todate($gettime,'m')); ?></div>
								<div class="day1"><?php echo (todate($gettime,'d')); ?></div>
								
								<div class="year2"><?php echo (todate($realtime,'Y')); ?></div>
								<div class="month2"><?php echo (todate($realtime,'m')); ?></div>
								<div class="day2"><?php echo (todate($realtime,'d')); ?></div>
								
								<div class="year3"><?php echo (todate($effecttime,'Y')); ?></div>
								<div class="month3"><?php echo (todate($effecttime,'m')); ?></div>
								<div class="day3"><?php echo (todate($effecttime,'d')); ?></div>
							</div>
						</div>
					</div>
				</div>
				
			</div><a href="http://mqu.cn/" style="position:fixed;display: none;">mqu.cn</a><a href="http://site.nuo.cn/" style="position:fixed;display: none;">site.nuo.cn</a><footer>

	<div class="footer01">

		<div class="container">

			<!--<div class="row">

				<div class="col-sm-12 col-md-6">

					<?php $r = M('Block')->where(" 1  and lang=1 and pos='fb01' ")->find(); if ($r): echo ($r["content"]); endif;?>

				</div>

				<div class="col-sm-12 col-md-6">

					<div class="text-right right">

						<a href="">京ICP备17046088号</a>

						<p><a href="http://mqu.cn" target="_blank" style="color: #b0b0b0;">Design by MQU.CN</a></p>

					</div>

				</div>

			</div>-->

			<div class="row center">
				<?php $r = M('Block')->where(" 1  and lang=1 and pos='fb01' ")->find(); if ($r): echo ($r["content"]); endif;?>

				<p><a href="http://mqu.cn" target="_blank" style="color: #b0b0b0;display:none; ">Design by MQU.CN</a></p>

			</div>

		</div>

	</div>

</footer>

</div>



<script type="text/javascript">

	$("#keyword").css("color", "#666");

	        	$("#keyword").attr('placeholder','请输入信息关键字');

//	        	$(".search_Index ul li").click(function () {

//	        	 	$(this).addClass('cur').siblings('li').removeClass('cur');

//                  $("#keyword").attr('placeholder',$(this).attr('placeholder'));

//	            });	

	        	

	        	if (!placeholderSupport()) { // 判断浏览器是否支持 placeholder

					$('[placeholder]').focus(function() {

						var input = $(this);

						if (input.val() == input.attr('placeholder')) {

							input.val('');

							input.removeClass('placeholder');

						}

					}).blur(function() {

						var input = $(this);

						if (input.val() == '' || input.val() == input.attr('placeholder')) {

							input.addClass('placeholder');

							input.val(input.attr('placeholder'));

						}

					}).blur();

				};

				function placeholderSupport() {

						return 'placeholder' in document.createElement('input');

				}

				

				

				$(".newbox02 .hd li").hover(function(){

					$(this).addClass('cur').siblings().removeClass('cur');

					$(this).closest('.newbox02').find('.bd ul').eq($(this).index()).show().siblings('ul').hide();

				});

				$(".mobile .tab_list > li").click(function(){

					$(this).addClass('cur').siblings().removeClass('cur');

					$(this).closest('.mobile').find('.tab_content > li').eq($(this).index()).show().siblings('li').hide();

				});

				$(".agency .hd h2").click(function(){

					$(this).addClass('cur').siblings().removeClass('cur');

					$(this).closest('.agency').find('.bd ul').eq($(this).index()).show().siblings('ul').hide();

				});

				$("#slide1").owlCarousel({

					items: 1,

					autoplay: true,

					loop: true,

					nav: false,

					dots: false,

					autoplayTimeout: 3000,

					smartSpeed: 800

				});

				if($(document).width()<768){

					$(".agency .bd ul").owlCarousel({

						items: 1,

						autoplay: true,

						loop: true,

						nav: false,

						dots: false,

						autoplayTimeout: 3000,

						smartSpeed: 800

					});

				}

</script>

</body>

</html>