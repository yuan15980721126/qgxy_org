<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>

<html>

<head>

	<meta name="description" content="<?php echo ($seo_description); ?>">

	<meta name="keywords" content="<?php echo ($seo_keywords); ?>">

	<meta charset="utf-8">

	<meta name="renderer" content="webkit"><!--360 极速模式-->

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no"/>

	<title><?php echo ($seo_title); ?></title>

	<link rel="shortcut icon" href="/Apps/Tpl/Home/Default/Public/images/favicon.ico" />

	<link href="../Public/css/owl.carousel.2.2.1.css" rel="stylesheet" type="text/css" />

	<link href="../Public/css/reset.css" rel="stylesheet" type="text/css" />

	<link href="../Public/css/style.css" rel="stylesheet" type="text/css" />

	<?php if($module_name==Index) : ?>

	<link href="../Public/css/index.css" rel="stylesheet" type="text/css" />

	<?php endif;?>

	<link href="../Public/css/app.css" rel="stylesheet" type="text/css" />

	<!--[if lt IE 9]>

	<script src="../Public/js/html5.js"></script>

	<script src="../Public/js/respond.min.js"></script>

	<![endif]-->

	<script type="text/javascript" src="../Public/js/jquery-min.js"></script>

	<script src="../Public/js/owl.carousel.2.2.1.js" type="text/javascript" charset="utf-8"></script>

</head>

<body>

<div class="wrapper">

	<header>

	<div class="header01">

		<div class="container">

			<div class="row">

				<div class="left">

					<?php  $_result=M("Link")->field("*")->where(" 1  and lang=1 AND status=1 ")->order("listorder desc,id desc")->limit("3")->select();; if ($_result): $k=0;foreach($_result as $key=>$r):++$k;$mod = ($k % 2 );?><a href="<?php echo ($r["siteurl"]); ?>" target="_blank"><?php echo ($r["name"]); ?></a><?php if($k<3) : ?>  | <?php endif; endforeach; endif;?>

				</div>

				<div class="right">

					<a href="/">网站首页</a>｜

					<a href="<?php echo ($Categorys[$T[contact]][url]); ?>"><?php echo ($Categorys[$T[contact]][catname]); ?></a>｜

					<a href="<?php echo ($Categorys[$T[apply]][url]); ?>">信用报名</a>

				</div>

			</div>

		</div>

	</div>

	<div class="header02" style="background-image: url(../Public/images/banner01.jpg);">

		<div class="container">

			<div class="row">

				<div class="img-responsive">

					<a href="/"><img src="<?php echo ($logo); ?>"/></a>

				</div>

			</div>

		</div>

	</div>

	</header>



<style type="text/css">

		.header02{padding: 15px 0;}

		.pull-left{float: left;}

		.footer01{background: #164d81;}

	</style><?php if($module_name!=Index) : ?><div class="breadcrumb">	<div class="container">		<div class="row">			<!--<div class="right">-->				<!--<span>-->					<!--<a class="show" href="/">首页</a> &gt; <?php  $arrparentid = array_filter(explode(',', $Categorys[$catid]['arrparentid'].','.$catid));$icnt = 0;foreach($arrparentid as $cid):$parsestr[] = '<a '.(count($arrparentid)==(++$icnt)?'class="last"':"").' href="'.$Categorys[$cid]['url'].'">'.$Categorys[$cid]['catname'].'</a>'; endforeach;echo implode("<em>&gt;</em>",$parsestr);?> -->				<!--</span>-->			<!--</div>-->		</div>	</div></div><?php endif;?><div class="main clearfix">	<div class="mainContentLeft">		<div class="border_ddd clearfix">			<div class="leaveMessage" id="box3">				<style type="text/css">					#box3 .form span{width: 145px; text-align: right;padding-right: 10px;}				</style>				<form method="post" action="<?php echo URL('User-Post/insert');?>" id="detailForm">					<legend class="center font18">企业基本信息（全部必填）</legend>					<input type="hidden" name="catid" value="<?php echo ($catid); ?>" />					<input type="hidden" name="moduleid" value="6" />					<input type="hidden" name="lang" value="<?php echo ($langid); ?>" />					<ul class="form">						<li>							<span>企业名称：<b class="red">*</b></span>							<input type="text" name="companyname" required="required">						</li>						<li>							<span>	统一社会信用代码：<b class="red">*</b></span>							<input type="text" name="registernumber" required="required">						</li>						<li>							<span>企业类型：<b class="red">*</b></span>							<input type="text" name="companytype" required="required">						</li>						<li>							<span>法定代表人：<b class="red">*</b></span>							<input type="text" name="legalperson" required="required">						</li>						<li>							<span>成立日期：<b class="red">*</b></span>							<input type="text" name="date" required="required">						</li>						<li class="relative">							<span>注册资金：<b class="red">*</b></span>							<input type="text" name="registercapital" required="required">							<em>万元</em>						</li>						<li>							<span>登记机关：<b class="red">*</b></span>							<input type="text" name="address" required="required">						</li>						<li>							<span>经营期限：<b class="red">*</b></span>							<input type="text" name="dateto" required="required">						</li>						<li>							<span>经营范围：<b class="red">*</b></span>							<input type="text" name="range" required="required">						</li>												<li>							<span></span>							<p class="center font18" style="margin: 50px auto 10px;">联系人信息</p>						</li>						<li>							<span>联系人：<b class="red">*</b></span>							<input type="text" name="username" required="required">						</li>						<li>							<span>职务：<b class="red">*</b></span>							<input type="text" name="job" required="required">						</li>						<li>							<span>办公室电话：<b class="red">*</b></span>							<input type="tel" name="telephone" required="required">						</li>						<li>							<span>手机：<b class="red">*</b></span>							<input type="tel" name="ceilphone" required="required">						</li>						<li>							<span>QQ号码：<b class="red">*</b></span>							<input type="tel" name="qq" required="required">						</li>						<li>							<span>电子邮箱：<b class="red">*</b></span>							<input type="email" name="email" required="required">						</li>						<li>							<span></span>							<p class="center">								<input type="submit" name="" id="" value="提交" />								<input type="reset" name="" id="" value="重置" />							</p>						</li>					</ul>				</form>			</div>		</div>	</div>	<!--右侧公共部分-->	<div class="mainContentRightTips border_ddd">		<?php echo ($content); ?>	</div>	<!--右侧公共部分-->	</div><a href="http://mqu.cn/" style="position:fixed;display: none;">mqu.cn</a><a href="http://site.nuo.cn/" style="position:fixed;display: none;">site.nuo.cn</a><footer>

	<div class="footer01">

		<div class="container">

			<!--<div class="row">

				<div class="col-sm-12 col-md-6">

					<?php $r = M('Block')->where(" 1  and lang=1 and pos='fb01' ")->find(); if ($r): echo ($r["content"]); endif;?>

				</div>

				<div class="col-sm-12 col-md-6">

					<div class="text-right right">

						<a href="">京ICP备17046088号</a>

						<p><a href="http://mqu.cn" target="_blank" style="color: #b0b0b0;">Design by MQU.CN</a></p>

					</div>

				</div>

			</div>-->

			<div class="row center">
				<?php $r = M('Block')->where(" 1  and lang=1 and pos='fb01' ")->find(); if ($r): echo ($r["content"]); endif;?>

				<p><a href="http://mqu.cn" target="_blank" style="color: #b0b0b0;display:none; ">Design by MQU.CN</a></p>

			</div>

		</div>

	</div>

</footer>

</div>



<script type="text/javascript">

	$("#keyword").css("color", "#666");

	        	$("#keyword").attr('placeholder','请输入信息关键字');

//	        	$(".search_Index ul li").click(function () {

//	        	 	$(this).addClass('cur').siblings('li').removeClass('cur');

//                  $("#keyword").attr('placeholder',$(this).attr('placeholder'));

//	            });	

	        	

	        	if (!placeholderSupport()) { // 判断浏览器是否支持 placeholder

					$('[placeholder]').focus(function() {

						var input = $(this);

						if (input.val() == input.attr('placeholder')) {

							input.val('');

							input.removeClass('placeholder');

						}

					}).blur(function() {

						var input = $(this);

						if (input.val() == '' || input.val() == input.attr('placeholder')) {

							input.addClass('placeholder');

							input.val(input.attr('placeholder'));

						}

					}).blur();

				};

				function placeholderSupport() {

						return 'placeholder' in document.createElement('input');

				}

				

				

				$(".newbox02 .hd li").hover(function(){

					$(this).addClass('cur').siblings().removeClass('cur');

					$(this).closest('.newbox02').find('.bd ul').eq($(this).index()).show().siblings('ul').hide();

				});

				$(".mobile .tab_list > li").click(function(){

					$(this).addClass('cur').siblings().removeClass('cur');

					$(this).closest('.mobile').find('.tab_content > li').eq($(this).index()).show().siblings('li').hide();

				});

				$(".agency .hd h2").click(function(){

					$(this).addClass('cur').siblings().removeClass('cur');

					$(this).closest('.agency').find('.bd ul').eq($(this).index()).show().siblings('ul').hide();

				});

				$("#slide1").owlCarousel({

					items: 1,

					autoplay: true,

					loop: true,

					nav: false,

					dots: false,

					autoplayTimeout: 3000,

					smartSpeed: 800

				});

				if($(document).width()<768){

					$(".agency .bd ul").owlCarousel({

						items: 1,

						autoplay: true,

						loop: true,

						nav: false,

						dots: false,

						autoplayTimeout: 3000,

						smartSpeed: 800

					});

				}

</script>

</body>

</html>