<?php
/**
 * 
 * 数据库配置文件
 *
 * @package      	YOURPHP
 * @author          yourphp.cn QQ:147613338 <web@yourphp.cn>
 * @copyright     	Copyright (c) 2008-2011  (http://www.yourphp.cn)
 * @license         http://www.yourphp.cn/license.txt
 * @version        	config.php v2.0 2011-03-01 yourphp.cn $
 */
 return array(
	'DB_TYPE'=>'mysql',
	'DB_HOST'=>'127.0.0.1',
	'DB_NAME'=>'qgxytest_db',
	'DB_USER'=>'qgxytest_u',
	'DB_PWD'=>'123456',
	'DB_PORT'=>'3306',
	'DB_PREFIX'=>'mqu_',
);
?>
