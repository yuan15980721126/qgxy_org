<?php
header('Location: index.php?g=Admin&m=Login');
?>